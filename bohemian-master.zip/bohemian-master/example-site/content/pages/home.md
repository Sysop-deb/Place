Title: Responsive Pelican Theme
Tags: Home, Welcome, Announcement
URL:
save_as: index.html
Summary: Welcome to the Bohemian Theme for Peican

**Free**, **Responsive**, **Open Source**, &  ** Typographically Tasteful.** It’s *Bohemian* — the Pelican theme for snobs. Built for a great reading experience with minimal clutter, it will ready your Pelican site for 21<sup>st</sup> century.